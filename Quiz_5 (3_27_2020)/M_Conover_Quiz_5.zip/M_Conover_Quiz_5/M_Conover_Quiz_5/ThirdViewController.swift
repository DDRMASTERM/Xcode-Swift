//
//  ThirdViewController.swift
//  M_Conover_Quiz_5
//
//  Created by J. Matthew Conover on 3/27/20.
//  Copyright © 2020 J. Matthew Conover. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    var imageSource = ""
    
    @IBOutlet weak var imageDisplay: UIImageView!
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        imageDisplay.image = UIImage(named: imageSource.lowercased())
        label.text = imageSource
        // Do any additional setup after loading the view.
    }
    @IBAction func goBack(_ sender: Any) {
        presentingViewController?.dismiss(animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
