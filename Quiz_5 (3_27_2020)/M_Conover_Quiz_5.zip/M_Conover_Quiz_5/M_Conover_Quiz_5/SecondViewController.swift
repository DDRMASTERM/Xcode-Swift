//
//  SecondViewController.swift
//  M_Conover_Quiz_5
//
//  Created by J. Matthew Conover on 3/27/20.
//  Copyright © 2020 J. Matthew Conover. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        cell.textLabel?.text = arr[indexPath.row]
        return cell
    }
    
    @IBOutlet weak var myTable: UITableView!
    @IBOutlet weak var Error: UILabel!
    var search = ""
    var arr = [String]()
    func arrSetup() {
        var s = search
        var birds = ["Eagle", "Parrot", "Chicken", "Duck"]
        var sea = ["Dolphin", "Shark", "Octopus"]
        var reptiles = ["Snake", "Iguana"]
        var mammals = ["Horse", "Cow", "Sheep"]
        if s == "birds" || s == "bird"{
            arr.append(contentsOf: birds)
        }
        else if s == "sea creatures" || s == "sea creature"{
            arr.append(contentsOf: sea)
        }
        else if s == "reptiles" || s == "reptile"{
            arr.append(contentsOf: reptiles)
        }
        else if s == "mammals" || s == "mammal"{
            arr.append(contentsOf: mammals)
        }
        else if s == "all"{
            arr.append(contentsOf: birds)
            arr.append(contentsOf: sea)
            arr.append(contentsOf: reptiles)
            arr.append(contentsOf: mammals)
        }
        else {
            Error.text = "No results !! try again"
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        arrSetup()
        // Do any additional setup after loading the view.
        myTable.dataSource = self
        myTable.delegate = self
    }
    @IBAction func goBack(_ sender: Any) {
        presentingViewController?.dismiss(animated: true, completion: nil)
    }
    var x = 0
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.x = indexPath.row
        performSegue(withIdentifier: "seg2", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var dest = segue.destination as! ThirdViewController
        dest.imageSource = arr[x]
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
