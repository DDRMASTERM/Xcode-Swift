//
//  ViewController.swift
//  M_Conover_Quiz_5
//
//  Created by J. Matthew Conover on 3/27/20.
//  Copyright © 2020 J. Matthew Conover. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var searchField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var destination = segue.destination as! SecondViewController
        if searchField.text != nil{
            destination.search = searchField.text!
        }
    }
    

}

